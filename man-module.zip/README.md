# Nano for Android (aarch64)

## by nelshh @ xda-developers

This Magisk module installs the latest stable version of Nano to the target system

## Change Log

### v1.0 - 2019-08-07
* Initial release

## Source Code
* Source [git.savannah.gnu.org](http://git.savannah.gnu.org/cgit/nano.git)

## Module Source Code
* Module [GitHub](https://github.com/henriknelson/nano-magisk-module)

## Contact
* Developer: [henrik@cliffords.nu](mailto:henrik@cliffords.nu)
